Hubzu_SOP_Dynamic_Pricing_Model_Prediction <-
function(input_dat) {

### This function works for both single property and batch properties
### In batch mode, it requires that all properties have the same Most_Recent_List_Cycle.

#print("Hubzu_SOP_Dynamic_Pricing_Model_Prediction Ver_3_1 Build 2017-04-07")

### Define column names
### Not needed 

### Identify the model for this property
{
	if  (all(input_dat$Most_Recent_List_Cycle==2)) {
		if (! exists("Model_Production_Inputs_2w")) stop("No Model_Production_Inputs_2w")
		if (! exists("torpedo_model_list_2w")) stop("No torpedo_model_list_2w")
		if (! exists("torpedo_var_list_2w")) stop("No torpedo_var_list_2w")
		Model_Production_Inputs = Model_Production_Inputs_2w
		torpedo_model_list = torpedo_model_list_2w
		torpedo_var_list = torpedo_var_list_2w
	} else if (all(input_dat$Most_Recent_List_Cycle %in% c(4, 6))) {
		if (! exists("Model_Production_Inputs_4w")) stop("No Model_Production_Inputs_4w")
		if (! exists("torpedo_model_list_4w")) stop("No torpedo_model_list_4w")
		if (! exists("torpedo_var_list_4w")) stop("No torpedo_var_list_4w")
		Model_Production_Inputs = Model_Production_Inputs_4w
		torpedo_model_list = torpedo_model_list_4w
		torpedo_var_list = torpedo_var_list_4w
	} else if (all(input_dat$Most_Recent_List_Cycle %in% c(8, 10, 12))) {
		if (! exists("Model_Production_Inputs_8w")) stop("No Model_Production_Inputs_8w")
		if (! exists("torpedo_model_list_8w")) stop("No torpedo_model_list_8w")
		if (! exists("torpedo_var_list_8w")) stop("No torpedo_var_list_8w")
		Model_Production_Inputs = Model_Production_Inputs_8w
		torpedo_model_list = torpedo_model_list_8w
		torpedo_var_list = torpedo_var_list_8w
	} else {
		stop("Check Most_Recent_List_Cycle in the data. All properties must have the same Most_Recent_List_Cycle.")
	}

	if (! exists("Model_Prediction_Error")) stop("No Model_Prediction_Error")
	Error_week = ifelse( input_dat$Most_Recent_List_Cycle[1]==2, 2, ifelse( input_dat$Most_Recent_List_Cycle[1] %in% c(4, 6), 4, ifelse( input_dat$Most_Recent_List_Cycle[1] %in% c(8, 10, 12), 8) ) )
	Prediction_Error = Model_Prediction_Error[[paste("Week_", Error_week, sep="")]]
}

#print("Model_Production_Inputs and torpedo_var_list loaded")  
  
### Check character variables
{
	String_Variables = c("APPRTYP_CurrentList", "APPRTYP_FirstList", "CASH_ONLY_INDICATOR", "FINANCIAL_CONSIDERED_INDICATOR", 
	"First_List_SOP_Status", "Most_Recent_Occupancy_Status", "Most_Recent_Reserve_Price_Met", "Most_Recent_SOP_Status", "PROP_CNTY_VC", 
	"PROP_STAT_ID_VC_FK", "PROP_SUB_TYPE_ID_VC_FK", "RBID_PROP_ID_VC_PK", "REO_PROP_STTS_VC", "SELR_PROP_ID_VC_NN", 
	"CONDITIONCDE_CurrentList", "CONDITIONCDE_FirstList",
	"SELR_ACNT_ID_VC_FK", "Most_Recent_List_Status", "Most_Recent_Property_Status","Data_Run_Time")
	
	for (i in 1:length(String_Variables)) {
		input_dat[[String_Variables[i]]] = as.character(as.vector(input_dat[[String_Variables[i]]]))
	}
}

### Check factor variables levels
{
	factor_variables = names(input_dat)[grep("Ind_Factor_", names(input_dat))]
	for (i in 1:length(factor_variables)) {
		input_dat[[factor_variables[i]]] = factor(input_dat[[factor_variables[i]]], 
												  levels = levels(Model_Production_Inputs$dat[[factor_variables[i]]]))
	}
}

### Create model_data
{

dat = input_dat

### Define variable lists
xvars_all = sort(names(dat)[grep("Ind_", names(dat))])
xvars_factor_all = sort(names(dat)[grep("Ind_Factor_", names(dat))])
xvars_dummy_all = sort(names(dat)[grep("Ind_Dummy_", names(dat))])
xvars_dummy_all = xvars_dummy_all[! xvars_dummy_all=="Ind_Dummy_AllBidMissing"]

### Define model_formula
model_formula = paste(c("~ -1 ",  xvars_all), sep="", collapse=" + ")
for (i in 1:length(xvars_factor_all)) {
	model_formula = paste(c(model_formula, 
					paste(xvars_factor_all[i],"Ind_Dummy_AllBidMissing", sep="*")), sep="", collapse=" + ")
}
for (i in 1:length(xvars_dummy_all)) {
	model_formula = paste(c(model_formula, 
					paste(xvars_dummy_all[i],"Ind_Dummy_AllBidMissing", sep="*")), sep="", collapse=" + ")
}

### Generate model_data
model_data = data.frame(model.matrix(formula(model_formula), data=dat))
rownames(model_data) = dat$SELR_PROP_ID_VC_NN

### Scale inputs
XScaleInput = Model_Production_Inputs$XScaleInput
for (i in 1:nrow(XScaleInput)) {
	model_data[,rownames(XScaleInput)[i]] = (model_data[,rownames(XScaleInput)[i]] - XScaleInput[i,1])/XScaleInput[i,2]
}

### Re-name variables
names(model_data) = gsub("Ind_Dummy_AllBidMissing.Ind", "Ind_Dummy_AllBidMissing_Ind", names(model_data))
names(model_data) = gsub(".Ind_Dummy_AllBidMissing", "_Ind_Dummy_AllBidMissing", names(model_data))
}


#print("model_formula and model data processed")

### Run Torpedo Model Prediction
{
Torpedo_Prediction <- function(newdata, yvar, models.included) {

	require(stringr)
	require(caret)
	options(digits = 12)
	options(stringsAsFactors = TRUE)

	if (! yvar %in% names(torpedo_model_list)) {
		stop("Check torpedo_model_list or yvar !!!")
	} else {
		models.run.list = torpedo_model_list[[match(yvar, names(torpedo_model_list))]]
		selected.var.list = torpedo_var_list[[match(yvar, names(torpedo_model_list))]]
	}
	
	all.pred.res <- NULL
	run.transform <- yvar
	new.res.df <- NULL
		
	for (model.name in intersect(names(models.run.list), models.included)) {
		#model.name =intersect(names(models.run.list), models.included)[1]
		model.res <- models.run.list[[model.name]]
		# print(names(model.res))
		xvars <- model.res$vars
		# print(xvars)
		factor.cols <- sapply(newdata[,xvars, drop = FALSE], is.factor)
		cat.xvars <- xvars[factor.cols]
		num.xvars <- xvars[!factor.cols]
		new.x.num <- newdata[, num.xvars, drop = FALSE]
		new.x.cat <- newdata[, cat.xvars, drop = FALSE]

		model.res$trans = NULL
		if( !is.null(model.res$trans )) {
			print(trans.name)
			new.x.num <- predict(model.res$trans, new.x.num )
		} 
			
		if( ncol(new.x.cat) > 0 ) {
			new.x <- cbind(new.x.num, new.x.cat)
		} else {
			new.x <- new.x.num
		}

		# print( colnames(new.x) )
		pred.res <- predict(model.res$train, new.x)

		#### data frame for holding prediction results
		if( is.null(new.res.df) ){
			new.res.df <- pred.res
		} else {
			new.res.df <- cbind(new.res.df, pred.res)
		}
	}
		
	# colnames(new.res.df) <- paste(run.transform, models.included, sep = ".")
	colnames(new.res.df) <- paste(run.transform, intersect(names(models.run.list), models.included), sep = ".")
		
	if(is.null(all.pred.res) ){
		all.pred.res <- new.res.df
	} else {
		all.pred.res <- cbind(all.pred.res, new.res.df)
	}
	
	all.pred.res = cbind(all.pred.res, apply(all.pred.res, 1, mean))
	colnames(all.pred.res)[ncol(all.pred.res)] = paste(run.transform, ".avg", sep="")
	return(all.pred.res)
}

newdata = model_data
yvars_all =  names(torpedo_model_list)
models.included = c("rf", "cubist","gbm")
model.pred.raw = NULL
for (i in 1:length(yvars_all)) {
	yvar = yvars_all[i]
	pred = Torpedo_Prediction(newdata, yvar, models.included) 
	model.pred.raw = cbind(model.pred.raw, pred[, ncol(pred)])
	colnames(model.pred.raw)[ncol(model.pred.raw)] = colnames(pred)[ncol(pred)]
}
rownames(model.pred.raw) = rownames(newdata)
}

#print("raw predition is done")

### Convert Raw Prediction to Dollar Amount
{
model.pred.raw = as.data.frame(model.pred.raw)
model.pred.raw$SELR_PROP_ID_VC_NN = rownames(model.pred.raw)
model.pred.raw = merge(model.pred.raw, dat[, c("SELR_PROP_ID_VC_NN","First_List_Price","Most_Recent_List_Price",
					"Most_Recent_List_Cycle", "Current_List_Start_Date","Ind_Numeric_MarketLiquidity",
					"Ind_Dummy_AllBidMissing","Valuation_for_Initial_Listing")], by="SELR_PROP_ID_VC_NN")

YScaleInput = Model_Production_Inputs$YScaleInput

Pred_Final = data.frame(SELR_PROP_ID_VC_NN = model.pred.raw$SELR_PROP_ID_VC_NN, 
						First_List_Price = model.pred.raw$First_List_Price,
						Most_Recent_List_Price = model.pred.raw$Most_Recent_List_Price, 
						Most_Recent_List_Cycle = model.pred.raw$Most_Recent_List_Cycle, 
						Current_List_Start_Date = model.pred.raw$Current_List_Start_Date, 
						Ind_Numeric_MarketLiquidity = model.pred.raw$Ind_Numeric_MarketLiquidity, 
						Ind_Dummy_AllBidMissing = model.pred.raw$Ind_Dummy_AllBidMissing,
						Valuation_for_Initial_Listing = model.pred.raw$Valuation_for_Initial_Listing,
						stringsAsFactors=FALSE)

for (i in 1:length(yvars_all)) {
	yvar = yvars_all[i]
	YScale = YScaleInput[rownames(YScaleInput)==yvar,]
	yvar_hat_scaled = model.pred.raw[, paste(yvar, ".avg", sep="")]
	yvar_hat_unscaled = yvar_hat_scaled*YScale[2] + YScale[1]
	if (yvar == "Dep_Numeric_MaxAcptBidVsFirstListPrice") {
		yvar_hat_unscaled[yvar_hat_unscaled < -1] = -1 ### modification on raw model prediction
		Sale_hat = (1+yvar_hat_unscaled)*model.pred.raw$First_List_Price
	} else if (yvar == "Dep_Numeric_LogMaxAcptBid") {
		Sale_hat = exp(yvar_hat_unscaled) - 1
	} else if (yvar == "Dep_Numeric_MaxAcptBidVsMostRecentListPrice") {
		yvar_hat_unscaled[yvar_hat_unscaled < -1] = -1 ### modification on raw model prediction
		Sale_hat = (1+yvar_hat_unscaled)*model.pred.raw$Most_Recent_List_Price
	}
	Pred_Final = data.frame(Pred_Final, Sale_hat=Sale_hat)
	colnames(Pred_Final)[ncol(Pred_Final)] = paste("SalePrice_Pred_", yvar, sep="")
}
						
##head(Pred_Final)
### Calculate Ensemble Dollar Amount prediction
##Pred_Final = data.frame(Pred_Final, SalePrice_Pred_Ensemble = apply(Pred_Final[, grep("SalePrice_Pred_", colnames(Pred_Final))], 1, mean))

#Pred_Final = data.frame(Pred_Final)
if(Pred_Final$First_List_Price>750000) Pred_Final$SalePrice_Pred_Dep_Numeric_LogMaxAcptBid=NA
Pred_Final = data.frame(Pred_Final, SalePrice_Pred_Ensemble = apply(Pred_Final[, grep("SalePrice_Pred_", colnames(Pred_Final))], 1, mean,na.rm=TRUE))


### Calculate Ensemble Pct Change prediction (from most recent list price)
Pred_Final$SalePricePctChange_Pred_Ensemble = Pred_Final$SalePrice_Pred_Ensemble/Pred_Final$Most_Recent_List_Price - 1

}

#print("dollar prediction ensemble is done")

### Calculate Lower/Upper Bounds for X% Confidence Level
{
### High >= 1
### Medium >= -0.2
### Low < -0.2

# Confidence Upper Bounds for different local liquidity
# Target Reduction          High	Medium	Low
# W2   7-8%                 0.800	0.850	0.950
# W4   6-8%                 0.750   0.800   0.900
# W6   4-5%                 0.675   0.725   0.900
# W8   4-5%                 0.600   0.650   0.850
# W10  5-6%                 0.500   0.600   0.800
# W12  5-6%                 0.500   0.500   0.500

Liquidity = Pred_Final$Ind_Numeric_MarketLiquidity

# Confidence = (input_dat$Most_Recent_List_Cycle==2) *(0.95*(Liquidity < -0.2) + 0.85*(Liquidity >= -0.2 & Liquidity<1) +  0.80*(Liquidity >= 1)) +
			 # (input_dat$Most_Recent_List_Cycle==4) *(0.90*(Liquidity < -0.2) + 0.80*(Liquidity >= -0.2 & Liquidity<1) +   0.75*(Liquidity >= 1)) +
			 # (input_dat$Most_Recent_List_Cycle==6) *(0.90*(Liquidity < -0.2) + 0.725*(Liquidity >= -0.2 & Liquidity<1) + 0.675*(Liquidity >= 1)) +
			 # (input_dat$Most_Recent_List_Cycle==8) *(0.85*(Liquidity < -0.2) + 0.70*(Liquidity >= -0.2 & Liquidity<1) +  0.65*(Liquidity >= 1)) +
			 # (input_dat$Most_Recent_List_Cycle==10)*(0.85*(Liquidity < -0.2) + 0.70*(Liquidity >= -0.2 & Liquidity<1) +  0.65*(Liquidity >= 1)) +
			 # (input_dat$Most_Recent_List_Cycle==12)*(0.85*(Liquidity < -0.2) + 0.70*(Liquidity >= -0.2 & Liquidity<1) +  0.65*(Liquidity >= 1))
			 
Confidence = (Pred_Final$Most_Recent_List_Cycle==2) *(0.985*(Liquidity < -0.2) + 0.9*(Liquidity >= -0.2 & Liquidity<1) +  0.82*(Liquidity >= 1)) +
			 (Pred_Final$Most_Recent_List_Cycle==4) *(0.93*(Liquidity < -0.2) + 0.83*(Liquidity >= -0.2 & Liquidity<1) +   0.78*(Liquidity >= 1)) +
			 (Pred_Final$Most_Recent_List_Cycle==6) *(0.94*(Liquidity < -0.2) + 0.765*(Liquidity >= -0.2 & Liquidity<1) + 0.725*(Liquidity >= 1)) +
			 (Pred_Final$Most_Recent_List_Cycle==8) *(0.89*(Liquidity < -0.2) + 0.74*(Liquidity >= -0.2 & Liquidity<1) +  0.7*(Liquidity >= 1)) +
			 (Pred_Final$Most_Recent_List_Cycle==10)*(0.88*(Liquidity < -0.2) + 0.73*(Liquidity >= -0.2 & Liquidity<1) +  0.68*(Liquidity >= 1)) +
			 (Pred_Final$Most_Recent_List_Cycle==12)*(0.88*(Liquidity < -0.2) + 0.73*(Liquidity >= -0.2 & Liquidity<1) +  0.68*(Liquidity >= 1))
Confidence=Confidence-0.09
Confidence[Confidence>=1]=0.995
###	 Get Prediction Bounds
RowPos = 1*(as.numeric(Pred_Final$Ind_Dummy_AllBidMissing)==1) + 3*(as.numeric(Pred_Final$Ind_Dummy_AllBidMissing)==0)
LB = Prediction_Error$Limit[RowPos]
UB = Prediction_Error$Limit[RowPos+1]
Pred_Final$SalePricePctChange_Pred_Ensemble = ifelse(Pred_Final$SalePricePctChange_Pred_Ensemble < LB, LB, 
												ifelse(Pred_Final$SalePricePctChange_Pred_Ensemble > UB, UB,
														Pred_Final$SalePricePctChange_Pred_Ensemble))

###	 Get Prediction Error Model Coefficients													
LB_coefficient = Prediction_Error[RowPos, c("Intercept","ypred")]; UB_coefficient = Prediction_Error[RowPos+1, c("Intercept","ypred")]
														
Pred_Final$SalePricePctChange_80PCT_LB = rowSums(LB_coefficient * cbind(rep(1, nrow(Pred_Final)), Pred_Final$SalePricePctChange_Pred_Ensemble))												
Pred_Final$SalePricePctChange_80PCT_UB = rowSums(UB_coefficient * cbind(rep(1, nrow(Pred_Final)), Pred_Final$SalePricePctChange_Pred_Ensemble))										

Pred_Final$Confidence_Selected = Confidence

Pred_Final$SalePricePctChange_Selected_UB = Pred_Final$SalePricePctChange_Pred_Ensemble + 
							(Pred_Final$SalePricePctChange_80PCT_UB-Pred_Final$SalePricePctChange_Pred_Ensemble)*qnorm(1-(1-Confidence)/2)/qnorm(1-(1-0.8)/2)
							
}

### Calculate Final Price Adjustment Recommendation
{

# X = Listing Price Adjustment (from the Most Recent Listing Price), either % or $, depending on the context.

# (1)	For end of week 8, if the cumulative listing price adjustment (i.e. most recent listing price from the first listing price) is smaller than 10%, Set min X = -5%
# 		For end of week 10, if the cumulative listing price adjustment (i.e. most recent listing price from the first listing price) is smaller than 12.5%, Set min X = -5%
# 		For end of week 12, if the cumulative listing price adjustment (i.e. most recent listing price from the first listing price) is smaller than 15%, Set min X = -5%
# (2)	-15% lower bound for 100K-, -12% for 100K-200K, -10% for 200K-500K and -8% for 500K+
# (3)	If X is between -500 and 0 (0 excluded), set X = -500.
# (4)	If X is between -1000 and -500, set X = -1000.
# (5)	For end of week 10 and 12, if X is between -5000 and 0 (0 excluded), set X = -5000 for Most_Recent_List_Price > 10000. 
#       In other words, the minimum reduction (if reduction is recommended) is 5000 for these two cycles.
#		For end of week 10 and 12, if X is between -5000 and 0 (0 excluded), set X = -5000 for Most_Recent_List_Price < 10000. 
#       In other words, the minimum reduction (if reduction is recommended) is half of the Most_Recent_List_Price.

### Percent Adjustment from Most Recent List Price
Pred_Final$List_Price_Percent_Adjustment_Recommendation = round(Pred_Final$SalePricePctChange_Selected_UB,4)
Pred_Final$LP_PCT_ADJ_UNADJUSTED = Pred_Final$List_Price_Percent_Adjustment_Recommendation

### Cumulative Change for week 8
Check_Condition = (Pred_Final$Most_Recent_List_Price/Pred_Final$First_List_Price - 1 > -0.1 & Pred_Final$List_Price_Percent_Adjustment_Recommendation > -0.05 & 
					Pred_Final$Most_Recent_List_Cycle==8)
if (any(Check_Condition)) Pred_Final$List_Price_Percent_Adjustment_Recommendation[Check_Condition] = -0.05

### Cumulative Change for week 10
Check_Condition = (Pred_Final$Most_Recent_List_Price/Pred_Final$First_List_Price - 1 > -0.125 & Pred_Final$List_Price_Percent_Adjustment_Recommendation > -0.05 & 
					Pred_Final$Most_Recent_List_Cycle==10)
if (any(Check_Condition)) Pred_Final$List_Price_Percent_Adjustment_Recommendation[Check_Condition] = -0.05

### Cumulative Change for week 12
Check_Condition = (Pred_Final$Most_Recent_List_Price/Pred_Final$First_List_Price - 1 > -0.15 & Pred_Final$List_Price_Percent_Adjustment_Recommendation > -0.05 & 
					Pred_Final$Most_Recent_List_Cycle==12)
if (any(Check_Condition)) Pred_Final$List_Price_Percent_Adjustment_Recommendation[Check_Condition] = -0.05

### Lower bounds based on prior listing price
### -15% lower bound for 100K-, -12% for 100K-200K, -10% for 200K-500K and -8% for 500K+
Percent_Adjustment_LB = -0.15*(Pred_Final$Most_Recent_List_Price < 100000) +
						-0.12*(Pred_Final$Most_Recent_List_Price < 200000 & Pred_Final$Most_Recent_List_Price >= 100000) +
						-0.10*(Pred_Final$Most_Recent_List_Price < 500000 & Pred_Final$Most_Recent_List_Price >= 200000) +
						-0.08*(Pred_Final$Most_Recent_List_Price >=  500000)

Check_Condition = Pred_Final$List_Price_Percent_Adjustment_Recommendation < Percent_Adjustment_LB
if (any(Check_Condition)) Pred_Final$List_Price_Percent_Adjustment_Recommendation[Check_Condition] = Percent_Adjustment_LB[Check_Condition]

Pred_Final$LP_PCT_ADJ_ADJUSTED1 = Pred_Final$List_Price_Percent_Adjustment_Recommendation


### Lower bounds based on initial valuation
### Check price change against initial valuation
# WinterTestProperties = unique(input_dat$SELR_PROP_ID_VC_NN[input_dat$Assignment=="Winter Test"])

Pred_Final$List_Price_Dollar_Adjustment_Recommendation = Pred_Final$List_Price_Percent_Adjustment_Recommendation*Pred_Final$Most_Recent_List_Price
Percent_Adjustment_from_Valuation = (Pred_Final$Most_Recent_List_Price + Pred_Final$List_Price_Dollar_Adjustment_Recommendation)/Pred_Final$Valuation_for_Initial_Listing - 1

Percent_Adjustment_from_Valuation_LB =  (Pred_Final$Most_Recent_List_Cycle[1]==2 & Pred_Final$Valuation_for_Initial_Listing < 100000)*(0) +
										(Pred_Final$Most_Recent_List_Cycle[1]==2 & Pred_Final$Valuation_for_Initial_Listing < 200000 & Pred_Final$Valuation_for_Initial_Listing >= 100000)*(0) +
										(Pred_Final$Most_Recent_List_Cycle[1]==2 & Pred_Final$Valuation_for_Initial_Listing < 500000 & Pred_Final$Valuation_for_Initial_Listing >= 200000)*(0) +
										(Pred_Final$Most_Recent_List_Cycle[1]==2 & Pred_Final$Valuation_for_Initial_Listing >= 500000)*(0.01) +
										
										(Pred_Final$Most_Recent_List_Cycle[1]==4 & Pred_Final$Valuation_for_Initial_Listing < 100000)*(-0.07) +
										(Pred_Final$Most_Recent_List_Cycle[1]==4 & Pred_Final$Valuation_for_Initial_Listing < 200000 & Pred_Final$Valuation_for_Initial_Listing >= 100000)*(-0.07) +
										(Pred_Final$Most_Recent_List_Cycle[1]==4 & Pred_Final$Valuation_for_Initial_Listing < 500000 & Pred_Final$Valuation_for_Initial_Listing >= 200000)*(-0.05) +
										(Pred_Final$Most_Recent_List_Cycle[1]==4 & Pred_Final$Valuation_for_Initial_Listing >= 500000)*(-0.04) +
										
										(Pred_Final$Most_Recent_List_Cycle[1]==6 & Pred_Final$Valuation_for_Initial_Listing < 100000)*(-0.14) +
										(Pred_Final$Most_Recent_List_Cycle[1]==6 & Pred_Final$Valuation_for_Initial_Listing < 200000 & Pred_Final$Valuation_for_Initial_Listing >= 100000)*(-0.11) +
										(Pred_Final$Most_Recent_List_Cycle[1]==6 & Pred_Final$Valuation_for_Initial_Listing < 500000 & Pred_Final$Valuation_for_Initial_Listing >= 200000)*(-0.09) +
										(Pred_Final$Most_Recent_List_Cycle[1]==6 & Pred_Final$Valuation_for_Initial_Listing >= 500000)*(-0.07) +
										
										(Pred_Final$Most_Recent_List_Cycle[1]==8 & Pred_Final$Valuation_for_Initial_Listing < 100000)*(-0.20) +
										(Pred_Final$Most_Recent_List_Cycle[1]==8 & Pred_Final$Valuation_for_Initial_Listing < 200000 & Pred_Final$Valuation_for_Initial_Listing >= 100000)*(-0.15) +
										(Pred_Final$Most_Recent_List_Cycle[1]==8 & Pred_Final$Valuation_for_Initial_Listing < 500000 & Pred_Final$Valuation_for_Initial_Listing >= 200000)*(-0.12) +
										(Pred_Final$Most_Recent_List_Cycle[1]==8 & Pred_Final$Valuation_for_Initial_Listing >= 500000)*(-0.11) +
										
										(Pred_Final$Most_Recent_List_Cycle[1]==10 & Pred_Final$Valuation_for_Initial_Listing < 100000)*(-0.20) +
										(Pred_Final$Most_Recent_List_Cycle[1]==10 & Pred_Final$Valuation_for_Initial_Listing < 200000 & Pred_Final$Valuation_for_Initial_Listing >= 100000)*(-0.15) +
										(Pred_Final$Most_Recent_List_Cycle[1]==10 & Pred_Final$Valuation_for_Initial_Listing < 500000 & Pred_Final$Valuation_for_Initial_Listing >= 200000)*(-0.12) +
										(Pred_Final$Most_Recent_List_Cycle[1]==10 & Pred_Final$Valuation_for_Initial_Listing >= 500000)*(-0.11) +
										
										(Pred_Final$Most_Recent_List_Cycle[1]==12 & Pred_Final$Valuation_for_Initial_Listing < 100000)*(-0.20) +
										(Pred_Final$Most_Recent_List_Cycle[1]==12 & Pred_Final$Valuation_for_Initial_Listing < 200000 & Pred_Final$Valuation_for_Initial_Listing >= 100000)*(-0.15) +
										(Pred_Final$Most_Recent_List_Cycle[1]==12 & Pred_Final$Valuation_for_Initial_Listing < 500000 & Pred_Final$Valuation_for_Initial_Listing >= 200000)*(-0.12) +
										(Pred_Final$Most_Recent_List_Cycle[1]==12 & Pred_Final$Valuation_for_Initial_Listing >= 500000)*(-0.11)

Pred_Final$Percent_Adjustment_from_Valuation_LB = Percent_Adjustment_from_Valuation_LB	
Pred_Final$PCT_ADJ_from_VAL_LB_HIT = ifelse(Percent_Adjustment_from_Valuation<Percent_Adjustment_from_Valuation_LB, "Yes", "No")

Percent_Adjustment_from_Valuation[Percent_Adjustment_from_Valuation<Percent_Adjustment_from_Valuation_LB] = 
				Percent_Adjustment_from_Valuation_LB[Percent_Adjustment_from_Valuation<Percent_Adjustment_from_Valuation_LB]

Pred_Final$List_Price_Dollar_Adjustment_Recommendation = Pred_Final$Valuation_for_Initial_Listing*(1+Percent_Adjustment_from_Valuation) - Pred_Final$Most_Recent_List_Price
Pred_Final$List_Price_Percent_Adjustment_Recommendation = round(Pred_Final$List_Price_Dollar_Adjustment_Recommendation/Pred_Final$Most_Recent_List_Price,4)
Pred_Final$LP_PCT_ADJ_ADJUSTED2 = Pred_Final$List_Price_Percent_Adjustment_Recommendation

### Upper bounds based on prior listing price
### -0.5% upper bound
Percent_Adjustment_UB = -0.005
Check_Condition = Pred_Final$List_Price_Percent_Adjustment_Recommendation > Percent_Adjustment_UB
if (any(Check_Condition)) Pred_Final$List_Price_Percent_Adjustment_Recommendation[Check_Condition] = Percent_Adjustment_UB

### Dollar Adjustment from Most Recent List Price
Pred_Final$List_Price_Dollar_Adjustment_Recommendation = Pred_Final$Most_Recent_List_Price*Pred_Final$List_Price_Percent_Adjustment_Recommendation

###This is what have been added
###reduction cannot be larger than 10% inital valuation
Check_Condition=Pred_Final$List_Price_Dollar_Adjustment_Recommendation < -0.1*Pred_Final$Valuation_for_Initial_Listing
if (any(Check_Condition)) Pred_Final$List_Price_Dollar_Adjustment_Recommendation[Check_Condition] = -0.1*Pred_Final$Valuation_for_Initial_Listing[Check_Condition]

# ### Below 500 => 500
# Check_Condition = Pred_Final$List_Price_Dollar_Adjustment_Recommendation < 0 & Pred_Final$List_Price_Dollar_Adjustment_Recommendation> -500
# if (any(Check_Condition)) Pred_Final$List_Price_Dollar_Adjustment_Recommendation[Check_Condition] = -500

# ### Between 500 and 1000 => 1000
# Check_Condition = Pred_Final$List_Price_Dollar_Adjustment_Recommendation < -500 & Pred_Final$List_Price_Dollar_Adjustment_Recommendation> -1000
# if (any(Check_Condition)) Pred_Final$List_Price_Dollar_Adjustment_Recommendation[Check_Condition] = -1000

### Below 2500 => 2500 new rule added in V2.5
Check_Condition = Pred_Final$List_Price_Dollar_Adjustment_Recommendation > -2500
if (any(Check_Condition)) Pred_Final$List_Price_Dollar_Adjustment_Recommendation[Check_Condition] = -2500

### Minimum 5000 reduction for week 10 and 12
Check_Condition = Pred_Final$List_Price_Dollar_Adjustment_Recommendation > -5000 & Pred_Final$Most_Recent_List_Cycle %in% c(10,12) &
				  Pred_Final$Most_Recent_List_Price >= 10000
if (any(Check_Condition)) Pred_Final$List_Price_Dollar_Adjustment_Recommendation[Check_Condition] = -5000

Check_Condition = Pred_Final$List_Price_Dollar_Adjustment_Recommendation> -5000 & Pred_Final$Most_Recent_List_Cycle %in% c(10,12) &
				  Pred_Final$Most_Recent_List_Price < 10000
if (any(Check_Condition)) Pred_Final$List_Price_Dollar_Adjustment_Recommendation[Check_Condition] = -Pred_Final$Most_Recent_List_Price[Check_Condition]*0.5

### Round current list price to Hundreds and modify price tiers
Current_List_Price = Pred_Final$Most_Recent_List_Price + Pred_Final$List_Price_Dollar_Adjustment_Recommendation
Current_List_Price = floor(Current_List_Price/100)*100
Current_List_Price[Current_List_Price<0] = 0

brks = sort(c(1:200*10000,25000,75000))
ranges = ifelse(brks < 50000, 100, ifelse(brks < 200000, 500, 1000))
for (i in 1:length(brks)) {
  Current_List_Price = ifelse(Current_List_Price >= brks[i] & Current_List_Price <  brks[i]+ranges[i], brks[i]-ranges[i], Current_List_Price)
}


### Final
Pred_Final$List_Price_Dollar_Adjustment_Recommendation = Current_List_Price - Pred_Final$Most_Recent_List_Price
Pred_Final$List_Price_Percent_Adjustment_Recommendation = round(Pred_Final$List_Price_Dollar_Adjustment_Recommendation/Pred_Final$Most_Recent_List_Price,4)
Pred_Final$Most_Recent_List_End_Date = Pred_Final$Current_List_Start_Date

### Pred_Final$Model_Version = paste("End of ", Pred_Final$Most_Recent_List_Cycle, " Listing Cycles", sep="")
Pred_Final$Model_Version = Model_Production_Inputs$model_version

if ((Pred_Final$Most_Recent_List_Cycle[1] %in% 6))
	Pred_Final$Model_Version = gsub("Week 4 Model", "Week 6 Model", Model_Production_Inputs$model_version)

if ((Pred_Final$Most_Recent_List_Cycle[1] %in% 10))
	Pred_Final$Model_Version = gsub("Week 8 Model", "Week 10 Model", Model_Production_Inputs$model_version)

if ((Pred_Final$Most_Recent_List_Cycle[1] %in% 12))
	Pred_Final$Model_Version = gsub("Week 8 Model", "Week 12 Model", Model_Production_Inputs$model_version)
	
Pred_Final$Model_Run_Time = as.character(paste(format(Sys.time(), tz="America/New_York"), "NY"))

}

#print("final price recommendation is done")
### Modify the order of output
{
	Pred_Final = Pred_Final[, match(c("SELR_PROP_ID_VC_NN",
	"First_List_Price",
	"Most_Recent_List_Price",
	"Most_Recent_List_Cycle",
	"Most_Recent_List_End_Date",
	"List_Price_Dollar_Adjustment_Recommendation",
	"List_Price_Percent_Adjustment_Recommendation",
	"Valuation_for_Initial_Listing",
	"Confidence_Selected",
	"SalePrice_Pred_Dep_Numeric_LogMaxAcptBid",
	"SalePrice_Pred_Dep_Numeric_MaxAcptBidVsFirstListPrice",
	"SalePrice_Pred_Dep_Numeric_MaxAcptBidVsMostRecentListPrice",
	"SalePrice_Pred_Ensemble",
	"SalePricePctChange_80PCT_LB",
	"SalePricePctChange_80PCT_UB",
	"SalePricePctChange_Pred_Ensemble",
	"SalePricePctChange_Selected_UB",
	"LP_PCT_ADJ_UNADJUSTED",
	"LP_PCT_ADJ_ADJUSTED1",
	"Percent_Adjustment_from_Valuation_LB",
	"PCT_ADJ_from_VAL_LB_HIT",
	"LP_PCT_ADJ_ADJUSTED2",
	"Model_Run_Time",
	"Model_Version"),names(Pred_Final))]
}

return(Pred_Final)

}

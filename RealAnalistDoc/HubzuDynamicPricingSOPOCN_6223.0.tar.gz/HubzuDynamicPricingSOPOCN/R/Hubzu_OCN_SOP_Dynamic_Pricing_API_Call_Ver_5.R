Hubzu_OCN_SOP_Dynamic_Pricing_API_Call_Ver_5 <-
function(Model_Raw_Data) {

	
	
	### Add dataframe column names
	names(Model_Raw_Data) = c("SELR_PROP_ID_VC_NN","SELR_ACNT_ID_VC_FK","RBID_PROP_ID_VC_PK","ADDRESS","PROP_CITY_VC_FK","PROP_STAT_ID_VC_FK","PROP_ZIP_VC_FK",
	"PROP_CNTY_VC","PROP_SUB_TYPE_ID_VC_FK","AREA_SQUR_FEET_NM","LOT_SIZE_VC","BDRM_CNT_NT","BTRM_CNT_NM","TOTL_ROOM_CNT_NM",
	"BULD_DATE_DT","REPR_VALU_NT","REO_PROP_STTS_VC","REO_DATE_DT","PROP_SOLD_DATE_DT","PROP_STTS_ID_VC_FK","RBID_PROP_LIST_ID_VC_PK",
	"LIST_TYPE_ID_VC_FK","RBID_PROP_ID_VC_FK","LIST_ATMP_NUMB_NT_NN","CURRENT_LIST_STRT_DATE","CURRENT_LIST_END_DATE","LIST_STTS_DTLS_VC",
	"PROPERTY_SOLD","ACTV_AUTO_BID","CURRENT_RSRV_PRCE_NT","CURRENT_LIST_PRCE_NT","HGST_BID_AMNT_NT","MINM_BID_AMNT_NT","OCCPNCY_STTS_AT_LST_CREATN",
	"SOP_PROGRAM_STATUS","IS_STAT_HOT_VC","BUY_IT_NOW_PRCE_NT","RSRV_PRCE_MET_VC","FALL_OUT_RESN_VC","FALL_OUT_DATE_DT","FINANCIAL_CONSIDERED_INDICATOR",
	"CASH_ONLY_INDICATOR","PROP_BIDDING_NUMBIDS","PROP_BIDDING_DISTINCT_BIDDERS","PROP_BIDDING_MAX_BID","PROP_BIDDING_MIN_BID",
	"TOTAL_NO_VIEWS","PROP_BIDDING_DSTNCT_WTCHLST","Actual_List_Cycle","Most_Recent_List_Cycle","APPRTYP_CurrentList","ASISMIDMKTVAL_CurrentList",
	"CONDITIONCDE_CurrentList","LIVINGAREA_CurrentList","TOTREPAIRAMT_CurrentList","APPRTYP_FirstList","ASISMIDMKTVAL_FirstList","CONDITIONCDE_FirstList",
	"LIVINGAREA_FirstList","TOTREPAIRAMT_FirstList","VALUATION_DATE","Valuation_for_Initial_Listing")
	library(HubzuDynamicPricingSOPModelV6)
	if(Model_Raw_Data$SELR_PROP_ID_VC_NN[as.numeric(Model_Raw_Data$Actual_List_Cycle)==max(as.numeric(Model_Raw_Data$ Actual_List_Cycle))] ==
	    Model_Raw_Data$SELR_PROP_ID_VC_NN[as.Date(Model_Raw_Data$CURRENT_LIST_STRT_DATE)==max(as.Date(Model_Raw_Data$CURRENT_LIST_STRT_DATE))] ) {
	   Model_Raw_Data$SELR_PROP_ID_VC_NN= Model_Raw_Data$SELR_PROP_ID_VC_NN[as.numeric(Model_Raw_Data$Actual_List_Cycle)==max(as.numeric(Model_Raw_Data$ Actual_List_Cycle))] 
	 }else{
	   print("check consistency of Property ID in different listing cycle")
	 }

	### Remove factors
	for (i in 1:ncol(Model_Raw_Data)) {
		if (is.factor(Model_Raw_Data[,i]))	Model_Raw_Data[,i] = as.vector(Model_Raw_Data[,i])
	}	
	
	### Define Date
	Date_Var_List = c("BULD_DATE_DT","REO_DATE_DT","CURRENT_LIST_STRT_DATE","CURRENT_LIST_END_DATE","VALUATION_DATE")
	for (i in 1:length(Date_Var_List)) {
		Model_Raw_Data[[Date_Var_List[i]]] = as.Date(Model_Raw_Data[[Date_Var_List[i]]])
	}
	
	###source_path = "C:\\Production\\Hubzu_Week_N_SOP\\Code\\V2.1\\Hubzu_SOP_Dynamic_Pricing_Model_Layer_I_Data_Step.R"
    ###source(source_path)
	###source_path = "C:\\Production\\Hubzu_Week_N_SOP\\Code\\V2.1\\Hubzu_SOP_Dynamic_Pricing_Model_Layer_II_Data_Step.R"
	###source_path =  "C:\\MyProjects\\SOP_Dynamic_Pricing_V2\\Production\\Code\\V2.1\\Hubzu_SOP_Dynamic_Pricing_Model_Prediction.R"
	
	Layer_I_Data_Step_Output = Hubzu_SOP_Dynamic_Pricing_Model_Layer_I_Data_Step(Model_Raw_Data) 
	Model_Layer_I_Data = Layer_I_Data_Step_Output$Model_Layer_I_Data
	#print(dim(Model_Layer_I_Data)) #114
		##unique(Model_Layer_I_Data$Most_Recent_List_Cycle) str(Model_Layer_I_Data)
		
	Layer_II_Data_Step_Output = Hubzu_SOP_Dynamic_Pricing_Model_Layer_II_Data_Step(Model_Layer_I_Data) 
	Model_Layer_II_Data = Layer_II_Data_Step_Output$Model_Layer_II_Data
	#print(dim(Model_Layer_II_Data)) # 163 ##165
	#print(head(Model_Layer_II_Data)) str(Model_Layer_II_Data)
	## "HGST_BID_STIGMA_ADJUSTED"? "Stigma_Adj"

	##names(Model_Layer_II_Data)[grep("Ind_", names(Model_Layer_II_Data))]
	##names(Model_Production_Inputs$dat)[grep("Ind_", names(Model_Production_Inputs$dat))]
	##unique(Model_Layer_II_Data$Most_Recent_List_Cycle)
	
	
	Output = Hubzu_SOP_Dynamic_Pricing_Model_Prediction(input_dat=Model_Layer_II_Data)
	Model_Layer_II_Data=Model_Layer_II_Data[,-match(c("Ind_Dummy_2017Listing", "Ind_Dummy_2018Listing", "Ind_Dummy_2019Listing"),
	                                                names(Model_Layer_II_Data))]
	ExcludedCols = ! names(Model_Layer_II_Data) %in% names(Output)
	ExcludedCols[1] = TRUE
	Model_Layer_II_Data = Model_Layer_II_Data[, ExcludedCols]
	
	Output = merge(Output, Model_Layer_II_Data, by = "SELR_PROP_ID_VC_NN")
	
	Output$Data_Run_Time = as.character(Output$Data_Run_Time)
	Output$Most_Recent_List_End_Date = as.character(Output$Most_Recent_List_End_Date)
	Output$BULD_DATE_DT = as.character(Output$BULD_DATE_DT)
	Output$REO_DATE_DT = as.character(Output$REO_DATE_DT)
	Output$First_List_Start_Date = as.character(Output$First_List_Start_Date)
	Output$Current_List_Start_Date = as.character(Output$Current_List_Start_Date)

	
	### Remove factors
	for (i in 1:ncol(Output)) {
		if (is.factor(Output[,i]))	Output[,i] = as.vector(Output[,i])
	}	
	
	
	return(Output)
}

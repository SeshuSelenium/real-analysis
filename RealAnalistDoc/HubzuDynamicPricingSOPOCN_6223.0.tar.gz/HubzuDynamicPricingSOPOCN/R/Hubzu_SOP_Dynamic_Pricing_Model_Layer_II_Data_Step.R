Hubzu_SOP_Dynamic_Pricing_Model_Layer_II_Data_Step <-
function(Model_Layer_I_Data) {

	#print("Hubzu_SOP_Dynamic_Pricing_Model_Layer_II_Data_Step Ver_3_1 Build 2017-04-07")
		
	dat = Model_Layer_I_Data
	
	dat$Ind_Dummy_EndCycle2 = 1*(dat$Most_Recent_List_Cycle %in% 2)
	dat$Ind_Dummy_EndCycle4 = 1*(dat$Most_Recent_List_Cycle %in% 4)
	dat$Ind_Dummy_EndCycle6 = 1*(dat$Most_Recent_List_Cycle %in% 6)
	dat$Ind_Dummy_EndCycle8 = 1*(dat$Most_Recent_List_Cycle %in% 8)
	dat$Ind_Dummy_EndCycle10 = 1*(dat$Most_Recent_List_Cycle %in% 10)
	dat$Ind_Dummy_EndCycle12 = 1*(dat$Most_Recent_List_Cycle %in% 12)
	
	### Group I: Auction related information
	{
		### First and Most Recent List Prices
		dat$Ind_Numeric_LogFirstListPrice = log(1 + dat$First_List_Price)
		dat$Ind_Numeric_LogMostRecentListPrice = log(1 + dat$Most_Recent_List_Price)

		### Most Recent Buy-It-Now Price
		dat$Ind_Numeric_LogMostRecentBIN = log(1 + dat$Most_Recent_Buy_It_Now_Price)
		dat$Ind_Dummy_MostRecentBINMissing = 1*(is.na(dat$Ind_Numeric_LogMostRecentBIN))
		dat$Ind_Numeric_LogMostRecentBIN[is.na(dat$Ind_Numeric_LogMostRecentBIN)] = 0
	
		### Dummy for List Price Drop by 10%+
		dat$Ind_Dummy_ListPriceBigDrop = 1*(dat$Ind_Numeric_ListPriceRatio < -0.10)
		
		### Cum Max Bid
		dat$Ind_Numeric_LogMaxCumBid = log(1+ifelse(is.na(dat$Cum_Max_Bid),0,dat$Cum_Max_Bid))
		
		### Most Recent Max Bid
		dat$Ind_Numeric_LogMaxMostRecentBid = log(1+ifelse(is.na(dat$Most_Recent_Max_Bid), 0, dat$Most_Recent_Max_Bid))
		
		### Dummy for Max Cum Bid	
		dat$Ind_Dummy_MaxCumBidHigherThanFLP = 1*(dat$Ind_Numeric_MaxCumBidFirstListPriceDiff > 0)
		dat$Ind_Dummy_MaxCumBidHigherThanRLP = 1*(dat$Ind_Numeric_MaxCumBidMostRecentListPriceDiff > 0)
			
		### Dummy for Max Most Recent Bid	
		dat$Ind_Dummy_MaxMostRecentBidHigherThanFLP = 1*(dat$Ind_Numeric_MaxMostRecentBidFirstListPriceDiff > 0)
		dat$Ind_Dummy_MaxMostRecentBidHigherThanRLP = 1*(dat$Ind_Numeric_MaxMostRecentBidMostRecentListPriceDiff > 0)
		
		### Cum Number of Views
		dat$Ind_Factor_CumNumViews = factor(ifelse(dat$Total_Cum_Number_Views>300,"Views300", 
												ifelse(dat$Total_Cum_Number_Views>200,"Views200", 
													ifelse(dat$Total_Cum_Number_Views>100,"Views100", 
														ifelse(dat$Total_Cum_Number_Views>50,"Views50", 
															ifelse(dat$Total_Cum_Number_Views>10,"Views10", "Views0"))))),
													levels = c("Views0", "Views10", "Views50", "Views100","Views200","Views300"))
		table(dat$Ind_Factor_CumNumViews)
		
		### Number of Cum Distinct Bidders
		dat$Ind_Factor_CumNumDistBidders = factor(ifelse(dat$Total_Cum_Number_Bidders>=5,"Bidder5orMore", 
													ifelse(dat$Total_Cum_Number_Bidders>=3,"Bidder3or4", 
													ifelse(dat$Total_Cum_Number_Bidders>=2,"Bidder2", 
													ifelse(dat$Total_Cum_Number_Bidders==1,"Bidder1","Bidder0")))),
													levels = c("Bidder0", "Bidder1", "Bidder2", "Bidder3or4","Bidder5orMore"))
		table(dat$Ind_Factor_CumNumDistBidders)
		
		### Number of Most Recent Distinct Bidders
		dat$Ind_Factor_MostRecentNumDistBidders = factor(ifelse(dat$Total_Most_Recent_Number_Bidders>=5,"Bidder5orMore", 
													ifelse(dat$Total_Most_Recent_Number_Bidders>=3,"Bidder3or4", 
													ifelse(dat$Total_Most_Recent_Number_Bidders>=2,"Bidder2", 
													ifelse(dat$Total_Most_Recent_Number_Bidders==1,"Bidder1","Bidder0")))),
													levels = c("Bidder0", "Bidder1", "Bidder2", "Bidder3or4","Bidder5orMore"))
		table(dat$Ind_Factor_MostRecentNumDistBidders)
		
		### Number of Cum Bids
		dat$Ind_Factor_CumNumBids = factor(ifelse(dat$Total_Cum_Number_Bids>=11,"Bid11orMore", 
											ifelse(dat$Total_Cum_Number_Bids>=5,"Bid5to10", 
											ifelse(dat$Total_Cum_Number_Bids>=2,"Bid2to4", 
											ifelse(dat$Total_Cum_Number_Bids==1,"Bid1", "Bid0")))),
											levels = c("Bid0", "Bid1", "Bid2to4", "Bid5to10","Bid11orMore"))
		table(dat$Ind_Factor_CumNumBids)
		
		### Number of Most Recent Bids
		dat$Ind_Factor_MostRecentNumBids = factor(ifelse(dat$Total_Most_Recent_Number_Bids>=11,"Bid11orMore", 
											ifelse(dat$Total_Most_Recent_Number_Bids>=5,"Bid5to10", 
											ifelse(dat$Total_Most_Recent_Number_Bids>=2,"Bid2to4", 
											ifelse(dat$Total_Most_Recent_Number_Bids==1,"Bid1", "Bid0")))),
											levels = c("Bid0", "Bid1", "Bid2to4", "Bid5to10","Bid11orMore"))
		table(dat$Ind_Factor_MostRecentNumBids)
		
		### Most_Recent_Reserve_Price_Met
		dat$Ind_Dummy_MostRecentResPriceMet = 1*(dat$Most_Recent_Reserve_Price_Met %in% "Y")
		
		### Cum Number of People on Watchlist
		dat$Ind_Factor_CumNumWatchlist = factor(ifelse(dat$Total_Cum_Number_Watchlist==0, "Watchlist0",
													ifelse(dat$Total_Cum_Number_Watchlist==1, "Watchlist1",
														ifelse(dat$Total_Cum_Number_Watchlist==2, "Watchlist2",
															ifelse(dat$Total_Cum_Number_Watchlist<=4, "Watchlist3to4",
																"Watchlist5orMore")))),
											levels = c("Watchlist0", "Watchlist1", "Watchlist2", "Watchlist3to4","Watchlist5orMore"))
		table(dat$Ind_Factor_CumNumWatchlist)
		
		### Most Recent Number of People on Watchlist
		dat$Ind_Factor_MostRecentNumWatchlist = factor(ifelse(dat$Most_Recent_Number_Watchlist==0, "Watchlist0",
													ifelse(dat$Most_Recent_Number_Watchlist==1, "Watchlist1",
														ifelse(dat$Most_Recent_Number_Watchlist==2, "Watchlist2",
															ifelse(dat$Most_Recent_Number_Watchlist<=4, "Watchlist3to4",
																"Watchlist5orMore")))),
											levels = c("Watchlist0", "Watchlist1", "Watchlist2", "Watchlist3to4","Watchlist5orMore"))									
		table(dat$Ind_Factor_MostRecentNumWatchlist)
		
		### Most Recent Number of Views
		dat$Ind_Factor_MostRecentNumViews = factor(ifelse(dat$Most_Recent_Number_Views>300,"Views300", 
														ifelse(dat$Most_Recent_Number_Views>200,"Views200", 
															ifelse(dat$Most_Recent_Number_Views>100,"Views100", 
																ifelse(dat$Most_Recent_Number_Views>50,"Views50", 
																	ifelse(dat$Most_Recent_Number_Views>10,"Views10", "Views0"))))),
													levels = c("Views0", "Views10", "Views50", "Views100","Views200","Views300"))
		table(dat$Ind_Factor_MostRecentNumViews)
		
		### Contract Fallouts
		dat$Ind_Dummy_ContractFallout = 1*(as.vector(dat$Total_Number_Fallouts)>0)

		### Cash Only Sale
		dat$Ind_Dummy_CashOnly = 1*(toupper(dat$CASH_ONLY_INDICATOR)=="Y")

		### Fin Aid Considered
		dat$Ind_Dummy_FinConsidered = 1*(toupper(dat$FINANCIAL_CONSIDERED_INDICATOR)=="Y")
		
		### SOP Status
		dat$Ind_Dummy_FirstListSOP = 1*(toupper(dat$First_List_SOP_Status) %in% "Y")
		dat$Ind_Dummy_MostRecentListSOP = 1*(toupper(dat$Most_Recent_SOP_Status) %in% "Y")
	}
			
	### Group II: Physical property related information
	{
		### Number of Bed Rooms
		dat$Ind_Factor_BDRM = factor(ifelse(dat$BDRM_CNT_NT<=1, "Bed1",
									 ifelse(dat$BDRM_CNT_NT<=3, "Bed2or3","Bed4plus")), 
										levels=c("Bed1", "Bed2or3", "Bed4plus"))
		table(dat$Ind_Factor_BDRM)
		
		### Number of Bath Rooms
		dat$Ind_Factor_BTRM = factor(ifelse(dat$BTRM_CNT_NM<1.5, "Bath1",
									 ifelse(dat$BTRM_CNT_NM==1.5, "Bath1andHalf",
									 ifelse(dat$BTRM_CNT_NM<2.5, "Bath2",
									 ifelse(dat$BTRM_CNT_NM==2.5, "Bath2andHalf","Bath3plus")))),
									 levels=c("Bath1", "Bath1andHalf", "Bath2", "Bath2andHalf","Bath3plus"))
		table(dat$Ind_Factor_BTRM)
		
		### Area Sq Feet
		dat$Ind_Numeric_LogAreaSqFt = log(1+dat$LivingAreaSqFt)
		dat = dat[,-match("LivingAreaSqFt",names(dat))]
		
		### Lot Size
		dat$Ind_Numeric_LogLotSqFt = log(1+dat$LOT_SIZE_VC)
				
		### Age of House
		# AGE = as.numeric(format(dat$Current_List_Start_Date,"%Y"))-as.numeric(format(dat$BULD_DATE_DT,"%Y"))
		dat$Ind_Factor_PropertyAge = factor(ifelse(dat$AGE<=5, "Age1to5",
											ifelse(dat$AGE<=20, "Age6to20",
											ifelse(dat$AGE<=50, "Age21to50", "Age50orMore"))), 
											levels=c("Age1to5", "Age6to20", "Age21to50","Age50orMore"))
		dat = dat[, -match("AGE", names(dat))]
		table(dat$Ind_Factor_PropertyAge)
		
		### House Condition
		dat$Ind_Factor_MostRecentCondition = dat$CONDITIONCDE_CurrentList
				
		### Property Type
		dat$Ind_Factor_PropType = factor(ifelse(toupper(dat$PROP_SUB_TYPE_ID_VC_FK) %in% "CO", "CO",
										 ifelse(toupper(dat$PROP_SUB_TYPE_ID_VC_FK) %in% "MF", "MF",
										 ifelse(toupper(dat$PROP_SUB_TYPE_ID_VC_FK) %in% "MH", "MH",
										 ifelse(toupper(dat$PROP_SUB_TYPE_ID_VC_FK) %in% "PF", "PF",
										 ifelse(toupper(dat$PROP_SUB_TYPE_ID_VC_FK) %in% "SF", "SF", "OT"))))), 
										 levels=c("CO", "MF", "MH", "OT","PF","SF"))
										
	}
		
	### Group III: property value related information
	{
		### Property Valuation
		dat$Ind_Numeric_LogMostRecentAV = log(1+dat$ASISMIDMKTVAL_CurrentList)
		
		### Repair Value
		dat$Ind_Numeric_LogMostRecentTotRepair = log(1+dat$TOTREPAIRAMT_CurrentList)
		dat$Ind_Dummy_ZeroRepair = 1*(dat$Ind_Numeric_LogMostRecentTotRepair==0)
	
		### APPRTYP
		dat$Ind_Factor_ApprType = factor(ifelse(toupper(dat$APPRTYP_CurrentList) %in% "A", "A",
											ifelse(toupper(dat$APPRTYP_CurrentList)  %in% "B", "B",
												ifelse(toupper(dat$APPRTYP_CurrentList)  %in% "E", "E",
													ifelse(toupper(dat$APPRTYP_CurrentList)  %in% "M", "M", "OT")))), 
										levels=c("A","B","E","M","OT"))
										
		### Stigma
		dat$Ind_Numeric_StigmaAmount = dat$First_List_Price*dat$Ind_Numeric_StigmaPct
		dat$Ind_Numeric_StigmaPct[dat$Ind_Numeric_StigmaPct>0] = 0
		
		### dat$Ind_Numeric_LogStigmaAmount	
		
	}
					
	### Group IV: other information
	{
		### REO_PROP_STTS_VC
		dat$Ind_Dummy_REOSFC = 1*(dat$REO_PROP_STTS_VC %in% "REOS/FC")
		dat$Ind_Dummy_REOSLC = 1*(dat$REO_PROP_STTS_VC %in% "REOS/LC")
		dat$Ind_Dummy_REOSRC = 1*(dat$REO_PROP_STTS_VC %in% "REOS/RC")
		
		### Most_Recent_Occupancy_Status
		dat$Ind_Dummy_MostRecentOccupancy = 1*(dat$Most_Recent_Occupancy_Status %in% "Y")
	}
	

	{
		dat$Data_Run_Time = Sys.time()

		dat$PROP_CNTY_VC[is.na(dat$PROP_CNTY_VC)] = "MISSING"
		dat$AREA_SQUR_FEET_NM[is.na(dat$AREA_SQUR_FEET_NM)] = 0
		dat$TOTL_ROOM_CNT_NM[is.na(dat$TOTL_ROOM_CNT_NM)] = 0
		dat$REPR_VALU_NT[is.na(dat$REPR_VALU_NT)] = 0

		dat$BULD_DATE_DT[is.na(dat$BULD_DATE_DT)] = "0001-01-01"
		dat$PROP_SOLD_DATE_DT[is.na(dat$PROP_SOLD_DATE_DT)] = "0001-01-01"
		dat$REO_DATE_DT[is.na(dat$REO_DATE_DT)] = "0001-01-01"

		dat$Most_Recent_Buy_It_Now_Price[is.na(dat$Most_Recent_Buy_It_Now_Price)] = 0
		dat$Cum_Max_Bid[is.na(dat$Cum_Max_Bid)] = 0
		dat$Most_Recent_Max_Bid[is.na(dat$Most_Recent_Max_Bid)] = 0
		dat$Most_Recent_Occupancy_Status[is.na(dat$Most_Recent_Occupancy_Status)] = "MISSING"

		for (i in 1:ncol(dat)) {
			if (is.numeric(dat[,i]))
				dat[,i] = round(dat[,i],12)
		}

	}
	
	dat$DaysBtwReviewAndListing_CurrentList = 999
	dat$DaysBtwReviewAndListing_FirstList = 999
	dat$HUB_SALE_PRICE = 999

	###########################################################################
	#####          				EXPORT OUTPUT	        		  	  	  #####
	###########################################################################
	Outputs = list( Model_Layer_II_Data = dat )

	return(Outputs)
}

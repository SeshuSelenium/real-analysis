Hubzu_SOP_Dynamic_Pricing_Model_Layer_I_Data_Step <-
function(Model_Raw_Data) {
	
  #names(Model_Production_Inputs_2w$FMHPI)=HPI_Column_Names
  #names(Model_Production_Inputs_4w$FMHPI)=HPI_Column_Names
  #names(Model_Production_Inputs_6w$FMHPI)=HPI_Column_Names
  #names(Model_Production_Inputs_8w$FMHPI)=HPI_Column_Names
  #names(Model_Production_Inputs_10w$FMHPI)=HPI_Column_Names
  #names(Model_Production_Inputs_12w$FMHPI)=HPI_Column_Names
	
	##require(HubzuDynamicPricingSOPModelV2)
	##data(Model_Production_Inputs_2w)
	
	Model_Production_Inputs = Model_Production_Inputs_2w
	#load("/raid1/users/analyst/Hubzu_Dynamic_Pricing_V8/Production/Core_Model/fmhpi.Rdata")
	library(FMHPI)
	HPI_FM_Monthly=FMHPI
	Model_Production_Inputs$FMHPI=FMHPI
	Hubzu_SQL_Data = Model_Raw_Data
		
	##########################################################################
	##### Hubzu_Property_Data
	##########################################################################
	Hubzu_Property_Variables = c("SELR_PROP_ID_VC_NN",
									"SELR_ACNT_ID_VC_FK",
									"RBID_PROP_ID_VC_PK",            
									"PROP_STAT_ID_VC_FK",            
									"PROP_ZIP_VC_FK",                
									"PROP_CNTY_VC",                   
									"PROP_SUB_TYPE_ID_VC_FK",        
									"AREA_SQUR_FEET_NM",            
									"LOT_SIZE_VC",                   
									"BDRM_CNT_NT",                   
									"BTRM_CNT_NM",                   
									"TOTL_ROOM_CNT_NM",              
									"BULD_DATE_DT",                  
									"REPR_VALU_NT",                   
									"REO_PROP_STTS_VC",              
									"REO_DATE_DT",                   
									"PROP_SOLD_DATE_DT")
			
	Hubzu_Property_Data = Hubzu_SQL_Data[, match(Hubzu_Property_Variables, names(Hubzu_SQL_Data))]
	Check_Condition = (! Hubzu_Property_Data$SELR_PROP_ID_VC_NN[1:(nrow(Hubzu_Property_Data)-1)] == Hubzu_Property_Data$SELR_PROP_ID_VC_NN[2:(nrow(Hubzu_Property_Data))])
	Check_Condition = c(Check_Condition, TRUE)
	Hubzu_Property_Data = Hubzu_Property_Data[Check_Condition,]
			
	##########################################################################
	##### Summarize auction data by property
	##########################################################################			
	### Max Accepted Bid
	Hubzu_Auction_Data = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN","HGST_BID_AMNT_NT")]
	Hubzu_Auction_Data$HGST_BID_AMNT_NT = NA
	
	### First_List_Price
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==1, c("SELR_PROP_ID_VC_NN", "CURRENT_LIST_PRCE_NT")]
	names(temp)[2] = "First_List_Price"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_List_Price
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "CURRENT_LIST_PRCE_NT")]
	names(temp)[2] = "Most_Recent_List_Price"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")

	### First_List_SOP_Status
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==1, c("SELR_PROP_ID_VC_NN", "SOP_PROGRAM_STATUS")]
	names(temp)[2] = "First_List_SOP_Status"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")

	### Most_Recent_SOP_Status
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "SOP_PROGRAM_STATUS")]
	names(temp)[2] = "Most_Recent_SOP_Status"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_Buy_It_Now_Price
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "BUY_IT_NOW_PRCE_NT")]
	names(temp)[2] = "Most_Recent_Buy_It_Now_Price"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Total_Number_Fallouts
	temp = tapply(Hubzu_SQL_Data$LIST_STTS_DTLS_VC, Hubzu_SQL_Data$SELR_PROP_ID_VC_NN, 
										function(x) { sum(toupper(x[1:(length(x)-1)]) %in% "FALLOUT", na.rm=TRUE) })										
	temp = data.frame(SELR_PROP_ID_VC_NN=names(temp), Total_Number_Fallouts=as.vector(temp))
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### CASH_ONLY_INDICATOR
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "CASH_ONLY_INDICATOR")]
	names(temp)[2] = "CASH_ONLY_INDICATOR"
	temp[! temp[,2] %in% "Y", 2] = "N"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### FINANCIAL_CONSIDERED_INDICATOR
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "FINANCIAL_CONSIDERED_INDICATOR")]
	names(temp)[2] = "FINANCIAL_CONSIDERED_INDICATOR"
	temp[! temp[,2] %in% "Y", 2] = "N"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Total_Cum_Number_Bids
	temp = tapply(Hubzu_SQL_Data$PROP_BIDDING_NUMBIDS, Hubzu_SQL_Data$SELR_PROP_ID_VC_NN, sum)
	temp = data.frame(SELR_PROP_ID_VC_NN=names(temp), Total_Cum_Number_Bids=as.vector(temp))
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Total_Most_Recent_Number_Bids
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "PROP_BIDDING_NUMBIDS")]
	names(temp)[2] = "Total_Most_Recent_Number_Bids"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")	
	
	### Total_Cum_Number_Bidders
	temp = tapply(Hubzu_SQL_Data$PROP_BIDDING_DISTINCT_BIDDERS, Hubzu_SQL_Data$SELR_PROP_ID_VC_NN, sum)
	temp = data.frame(SELR_PROP_ID_VC_NN=names(temp), Total_Cum_Number_Bidders=as.vector(temp))
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Total_Most_Recent_Number_Bidders
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "PROP_BIDDING_DISTINCT_BIDDERS")]
	names(temp)[2] = "Total_Most_Recent_Number_Bidders"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")	
	
	### Cum_Max_Bid
	temp = tapply(Hubzu_SQL_Data$HGST_BID_AMNT_NT, Hubzu_SQL_Data$SELR_PROP_ID_VC_NN, max, na.rm=TRUE)
	temp = data.frame(SELR_PROP_ID_VC_NN=names(temp), Cum_Max_Bid=as.vector(temp))
	temp[temp[,2] == -Inf,2] = NA
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")		
	
	### Most_Recent_Max_Bid
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "HGST_BID_AMNT_NT")]
	names(temp)[2] = "Most_Recent_Max_Bid"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")	
	
	### Total_Cum_Number_Views
	temp = tapply(Hubzu_SQL_Data$TOTAL_NO_VIEWS, Hubzu_SQL_Data$SELR_PROP_ID_VC_NN, sum, na.rm=TRUE)
	temp = data.frame(SELR_PROP_ID_VC_NN=names(temp), Total_Cum_Number_Views=as.vector(temp))
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_Number_Views
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "TOTAL_NO_VIEWS")]
	names(temp)[2] = "Most_Recent_Number_Views"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Total_Cum_Number_Watchlist
	temp = tapply(Hubzu_SQL_Data$PROP_BIDDING_DSTNCT_WTCHLST, Hubzu_SQL_Data$SELR_PROP_ID_VC_NN, sum, na.rm=TRUE)
	temp = data.frame(SELR_PROP_ID_VC_NN=names(temp), Total_Cum_Number_Watchlist=as.vector(temp))
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_Number_Watchlist
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "PROP_BIDDING_DSTNCT_WTCHLST")]
	names(temp)[2] = "Most_Recent_Number_Watchlist"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")	
	
	### First_List_Start_Date
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==1, c("SELR_PROP_ID_VC_NN", "CURRENT_LIST_STRT_DATE")]
	names(temp)[2] = "First_List_Start_Date"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Current_List_Start_Date
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "CURRENT_LIST_END_DATE")]
	names(temp)[2] = "Current_List_Start_Date"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_Occupancy_Status
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "OCCPNCY_STTS_AT_LST_CREATN")]
	names(temp)[2] = "Most_Recent_Occupancy_Status"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_Reserve_Price_Met
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "RSRV_PRCE_MET_VC")]
	names(temp)[2] = "Most_Recent_Reserve_Price_Met"
	temp[is.na(temp[,2]),2] = "N"
	temp[temp[,2] %in% "",2] = "N"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_List_Cycle
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "Most_Recent_List_Cycle")]
	names(temp)[2] = "Most_Recent_List_Cycle"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_List_Status
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "LIST_STTS_DTLS_VC")]
	names(temp)[2] = "Most_Recent_List_Status"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_Property_Status
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==Hubzu_SQL_Data$Most_Recent_List_Cycle, c("SELR_PROP_ID_VC_NN", "PROP_STTS_ID_VC_FK")]
	names(temp)[2] = "Most_Recent_Property_Status"
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Most_Recent_Property_Status
	temp = Hubzu_SQL_Data[Hubzu_SQL_Data$Actual_List_Cycle==1, c(1,grep("_CurrentList", names(Hubzu_SQL_Data)),grep("_FirstList", names(Hubzu_SQL_Data)),
																	match("Valuation_for_Initial_Listing", names(Hubzu_SQL_Data)))]
	Hubzu_Auction_Data = merge(Hubzu_Auction_Data, temp, by = "SELR_PROP_ID_VC_NN")
	
	### Merge Hubzu Property Data and Hubzu Auction Data
	Hubzu_Data = merge(Hubzu_Property_Data, Hubzu_Auction_Data, by="SELR_PROP_ID_VC_NN")
	Hubzu_Data = Hubzu_Data[order(Hubzu_Data$Most_Recent_List_Cycle, Hubzu_Data$SELR_PROP_ID_VC_NN),]


	#########################################################################
	#####  Merge MasterHubzuStage5 and Model_Production_Inputs
	#########################################################################
	### Inputs: MasterHubzuStage5Combined & Model_Production_Inputs
	{
	dat = Hubzu_Data

	### Get Zipcode Level Census Data
	Find_Proxy_Zip <- function(zip_missing, ziplist) {
				absdif = abs(matrix(zip_missing, nrow=length(ziplist), ncol=length(zip_missing), byrow = TRUE) - 
							 matrix(ziplist, nrow=length(ziplist), ncol=length(zip_missing)))
				return(ziplist[apply(absdif, 2, which.min)])
	}
	if ( sum(! dat$PROP_ZIP_VC_FK %in% Model_Production_Inputs$CensusData$Zip)>0 ) {
		dat$PROP_ZIP_VC_FK[! dat$PROP_ZIP_VC_FK %in% Model_Production_Inputs$CensusData$Zip] = 
				Find_Proxy_Zip(dat$PROP_ZIP_VC_FK[! dat$PROP_ZIP_VC_FK %in% Model_Production_Inputs$CensusData$Zip], Model_Production_Inputs$CensusData$Zip)
	}
	dat = merge(dat,Model_Production_Inputs$CensusData,by.x="PROP_ZIP_VC_FK",by.y="Zip")
				
	### Get State Level Summary Data
	dat = merge(dat,Model_Production_Inputs$SummaryDataByState,by.x="PROP_STAT_ID_VC_FK",by.y="State")
				
	### Get State_Property Stigma Data
	stigma = function(AV, state) {
		## Function to compute stigma, given a state and (HPA-adjusted) asset value (AV)
		## Assumes state.coeffs is available in the environment
		AV = as.numeric(AV)
		state = as.character(state)
		I.1 = ifelse(AV<50000,1,0); I.2 = ifelse(((AV>=50000) & (AV<100000)),1,0)
		b = as.numeric(Model_Production_Inputs$StigmaByState[state, c("Beta_0","Beta_1","Beta_2","Beta_3","Beta_4","Beta_5")])
		sp.hat = b[1] + I.1 * b[2] + I.2 * b[3] + AV * (b[4] + I.1 * b[5] + I.2 * b[6])
		st.hat = sp.hat/AV -1   # ideally, use HPA-adjusted AV instead of AV
		return(st.hat)
	}
	dat$Ind_Numeric_StigmaPct = apply(dat, 1, function(x) { stigma( x["First_List_Price"],x["PROP_STAT_ID_VC_FK"]) })
	
	### Get HPI Data
	{
	  HPI = as.data.frame(Model_Production_Inputs$FMHPI)
	LastYear = as.numeric(substr(HPI$Month[length(HPI$Month)],1,4))
	LastMonth = as.numeric(substr(HPI$Month[length(HPI$Month)],6,7))
			
	if (LastMonth %in% c(1:8)) {
		month_temp = c(paste("0",c((1+LastMonth):9), sep=""), "10", "11","12")
		temp = paste(LastYear, "M", month_temp, sep="")
		temp = c(temp, paste(1+LastYear, "M", c(paste("0",c(1:9), sep=""), "10","11","12"), sep=""))
	} else if (LastMonth %in% c(9, 10, 11)) {
		month_temp = c(paste(c((1+LastMonth):12), sep=""))
		temp = paste(LastYear, "M", month_temp, sep="")
		temp = c(temp, paste(1+LastYear, "M", c(paste("0",c(1:9), sep=""), "10","11","12"), sep=""))
	} else if (LastMonth %in% c(12)) {
		temp = NULL
		temp = c(temp, paste(1+LastYear, "M", c(paste("0",c(1:9), sep=""), "10","11","12"), sep=""))
	}

	HPI2 = as.data.frame(matrix(rep(as.numeric(HPI[nrow(HPI),]), length(temp)), nrow = length(temp), ncol = ncol(HPI), byrow = TRUE))
	names(HPI2) = names(HPI)
	HPI = rbind(HPI[match("2010M01", HPI[,1]):nrow(HPI),], HPI2); rm(HPI2)
	HPI[(1+nrow(HPI)-length(temp)):nrow(HPI),1] = temp; rm(temp)
			
	tempdat = dat[, c("SELR_PROP_ID_VC_NN", "PROP_ZIP_VC_FK", "PROP_STAT_ID_VC_FK")]
	tempdat$CurrentMonth = paste(format(dat$Current_List_Start_Date,"%Y"), "M", format(dat$Current_List_Start_Date,"%m"), sep="")
	names(tempdat)[2:3] = c("Zip","State")
	tempdat = merge(tempdat, Model_Production_Inputs$ZipcodeMSAMapping[, c("Zip", "MSA_FM")], by="Zip", all.x=TRUE)
	tempdat$MSA_FM[tempdat$MSA_FM %in% "Non-MSA"] <- NA
	tempdat$MSA_FM[is.na(tempdat$MSA_FM)] = tempdat$State[is.na(tempdat$MSA_FM)]
	tempdat$MSA_FM[tempdat$MSA_FM=="USA"] = tempdat$State[tempdat$MSA_FM=="USA"]

	HPI_out = NULL
	Month_Unique = sort(unique(tempdat$CurrentMonth))
	for (i in 1:length(Month_Unique)) {
		CurrentMonth = Month_Unique[i]
		PrevM= HPI$Month[match(CurrentMonth, HPI$Month)-1]
		PrevQ = HPI$Month[match(CurrentMonth, HPI$Month)-3]
		PrevY = HPI$Month[match(CurrentMonth, HPI$Month)-12]
		
		HPI_out = rbind(HPI_out, data.frame(SELR_PROP_ID_VC_NN=tempdat$SELR_PROP_ID_VC_NN[tempdat$CurrentMonth==CurrentMonth],	
									HPI_Current = as.numeric(HPI[HPI$Month==CurrentMonth, match(tempdat$MSA_FM[tempdat$CurrentMonth==CurrentMonth], names(HPI))]),
									HPI_PrevM = as.numeric(HPI[HPI$Month==PrevM, match(tempdat$MSA_FM[tempdat$CurrentMonth==CurrentMonth], names(HPI))]),
									HPI_PrevQ = as.numeric(HPI[HPI$Month==PrevQ, match(tempdat$MSA_FM[tempdat$CurrentMonth==CurrentMonth], names(HPI))]),
									HPI_PrevY = as.numeric(HPI[HPI$Month==PrevY, match(tempdat$MSA_FM[tempdat$CurrentMonth==CurrentMonth], names(HPI))])))
	}
	HPI_out$Ind_Numeric_CurrentHPI = HPI_out$HPI_Current
	HPI_out$Ind_Numeric_HPIChangefromPrevM = HPI_out$HPI_Current/HPI_out$HPI_PrevM - 1
	HPI_out$Ind_Numeric_HPIChangefromPrevQ = HPI_out$HPI_Current/HPI_out$HPI_PrevQ - 1
	HPI_out$Ind_Numeric_HPIChangefromPrevY = HPI_out$HPI_Current/HPI_out$HPI_PrevY - 1
	HPI_out = HPI_out[,c("SELR_PROP_ID_VC_NN","Ind_Numeric_CurrentHPI","Ind_Numeric_HPIChangefromPrevM","Ind_Numeric_HPIChangefromPrevQ","Ind_Numeric_HPIChangefromPrevY")]
	dat = merge(dat, HPI_out, by="SELR_PROP_ID_VC_NN")
	}

	### Get High School District
	dat$Ind_Factor_HighSchool = Model_Production_Inputs$HighSchoolRanking$School.Medal[match(dat$PROP_ZIP_VC_FK, Model_Production_Inputs$HighSchoolRanking$School.Zipcode)]
	dat$Ind_Factor_HighSchool[is.na(dat$Ind_Factor_HighSchool)] = "MISSING"
	dat$Ind_Factor_HighSchool = gsub(" Medal", "", dat$Ind_Factor_HighSchool)
	dat$Ind_Factor_HighSchool = factor(dat$Ind_Factor_HighSchool, levels=c("GOLD","SILVER","BRONZE","MISSING"))
	table(dat$Ind_Factor_HighSchool)

	### Get Market Liquidity
	Zips = dat$PROP_ZIP_VC_FK
	if (sum(! Zips %in% Model_Production_Inputs$MarketLiquidity$Zipcode) >0 ) {
		Zips[! Zips %in% Model_Production_Inputs$MarketLiquidity$Zipcode] = 
				Find_Proxy_Zip(Zips[! Zips %in% Model_Production_Inputs$MarketLiquidity$Zipcode], Model_Production_Inputs$MarketLiquidity$Zipcode)
	}
	dat$Ind_Numeric_MarketLiquidity = Model_Production_Inputs$MarketLiquidity$Final_Liquidity_Index[match(Zips, Model_Production_Inputs$MarketLiquidity$Zipcode)]
	rm(Zips)

	### RiskByRegions: State
	{
	# temp = tapply(dat$HGST_BID_AMNT_NT, dat$PROP_STAT_ID_VC_FK, sum)
	# temp1 = data.frame(State=names(temp), Value1=as.vector(temp))
	# temp = tapply(dat$First_List_Price, dat$PROP_STAT_ID_VC_FK, sum)
	# temp2 = data.frame(State=names(temp), Value2=as.vector(temp))
	# temp = merge(temp1, temp2)
	# temp$Ratio = temp$Value1/temp$Value2-1
	# temp = temp[order(temp$Ratio),]
		
	Macro_STATE_HighRisk_List = Model_Production_Inputs$RiskByRegions$Region[Model_Production_Inputs$RiskByRegions$Category=="State" & Model_Production_Inputs$RiskByRegions$Risk=="High"]
	Macro_STATE_MedRisk_List = Model_Production_Inputs$RiskByRegions$Region[Model_Production_Inputs$RiskByRegions$Category=="State" & Model_Production_Inputs$RiskByRegions$Risk=="Medium"]
	Macro_STATE_LowRisk_List = Model_Production_Inputs$RiskByRegions$Region[Model_Production_Inputs$RiskByRegions$Category=="State" & Model_Production_Inputs$RiskByRegions$Risk=="Low"]
	dat$Ind_Factor_StageGroups = factor(ifelse(dat$PROP_STAT_ID_VC_FK %in% Macro_STATE_LowRisk_List,"StateLowRisk",
										ifelse(dat$PROP_STAT_ID_VC_FK %in% Macro_STATE_MedRisk_List,"StateMedRisk",
										ifelse(dat$PROP_STAT_ID_VC_FK %in% Macro_STATE_HighRisk_List,"StateHighRisk", "StateMedLowRisk"))), 
										levels = c("StateLowRisk","StateMedLowRisk","StateMedRisk","StateHighRisk"))
	}
		
	### County
	{
	# temp = table(dat$PROP_CNTY_VC)
	# temp = data.frame(County=names(temp), Value0=as.vector(temp))
	# temp = temp[order(temp[,2]),]
	# temp0 = temp[temp[,2] >=50 & temp[,1]!="",]
	# temp = tapply(dat$HGST_BID_AMNT_NT, dat$PROP_CNTY_VC, sum)
	# temp1 = data.frame(County=names(temp), Value1=as.vector(temp))
	# temp = tapply(dat$First_List_Price, dat$PROP_CNTY_VC, sum)
	# temp2 = data.frame(County=names(temp), Value2=as.vector(temp))
	# temp = merge(temp0, temp1)
	# temp = merge(temp, temp2)
	# temp$Ratio = temp$Value1/temp$Value2-1
	# temp=temp[order(temp$Ratio),]
		
	Macro_COUNTY_HighRisk_List = Model_Production_Inputs$RiskByRegions$Region[Model_Production_Inputs$RiskByRegions$Category=="County" & Model_Production_Inputs$RiskByRegions$Risk=="High"]
	Macro_COUNTY_MedRisk_List = Model_Production_Inputs$RiskByRegions$Region[Model_Production_Inputs$RiskByRegions$Category=="County" & Model_Production_Inputs$RiskByRegions$Risk=="Medium"]
	Macro_COUNTY_MedLowRisk_List = Model_Production_Inputs$RiskByRegions$Region[Model_Production_Inputs$RiskByRegions$Category=="County" & Model_Production_Inputs$RiskByRegions$Risk=="MediumLow"]
	Macro_COUNTY_LowRisk_List = Model_Production_Inputs$RiskByRegions$Region[Model_Production_Inputs$RiskByRegions$Category=="County" & Model_Production_Inputs$RiskByRegions$Risk=="Low"]
	dat$Ind_Factor_CountyGroup = factor(ifelse(dat$PROP_CNTY_VC %in% Macro_COUNTY_LowRisk_List,"CountyLowRisk",
											ifelse(dat$PROP_CNTY_VC %in% Macro_COUNTY_MedLowRisk_List,"CountyMedLowRisk",
											ifelse(dat$PROP_CNTY_VC %in% Macro_COUNTY_MedRisk_List,"CountyMedRisk", 
											ifelse(dat$PROP_CNTY_VC %in% Macro_COUNTY_HighRisk_List,"CountyHighRisk", "OtherUnknown")))), 
											levels = c("CountyLowRisk","CountyMedLowRisk","CountyMedRisk","CountyHighRisk","OtherUnknown"))
				
	}

	}
	### Outputs: dat

	
	########################################################################
	### Define Dependent/Independent Variable
	########################################################################
	### Inputs: dat
	

	### Dependent Variables
	{
		### Modify First_List_Price if Most_Recent_List_Price is significantly different from First_List_Price
		# Cutoffs =   (dat$Most_Recent_List_Cycle==2)*(-0.1403622) +
					# (dat$Most_Recent_List_Cycle==4)*(-0.2478897) +
					# (dat$Most_Recent_List_Cycle==6)*(-0.3226763) +
					# (dat$Most_Recent_List_Cycle==8)*(-0.3605364) +
					# (dat$Most_Recent_List_Cycle==10)*(-0.4161805) +
					# (dat$Most_Recent_List_Cycle==12)*(-0.4262002)
					
		# Check_Condition = dat$Most_Recent_List_Price/dat$First_List_Price - 1 < Cutoffs
		# dat$First_List_Price_Orig = dat$First_List_Price
		# dat$First_List_Price[Check_Condition] = dat$Most_Recent_List_Price[Check_Condition]/(1+ Cutoffs[Check_Condition])
		
		### Dependent Variables
		# Base_Variable = "First_List_Price"
		# dat$Dep_Numeric_LogMaxAcptBid = log(1 + dat$HGST_BID_AMNT_NT)
		# dat$Dep_Numeric_MaxAcptBidBaseRatio = dat$HGST_BID_AMNT_NT/dat[[Base_Variable]] - 1
		# dat$Dep_Numeric_MaxAcptBidBaseDiff = dat$HGST_BID_AMNT_NT - dat[[Base_Variable]]
	}
	
	### Independent Variables
	
	### Group I: Auction related information
	{
		### $ Change for List Price
		dat$Ind_Numeric_ListPriceChange = dat$Most_Recent_List_Price-dat$First_List_Price
		
		### Pct Change for List Price
		dat$Ind_Numeric_ListPriceRatio = dat$Most_Recent_List_Price/dat$First_List_Price-1
				
		### Bid Missing in all listing cycles
		dat$Ind_Dummy_AllBidMissing = ifelse(is.na(as.vector(dat$Cum_Max_Bid)), 1,0)
		
		### Bid Missing in most recent listing cycle
		dat$Ind_Dummy_MostRecentBidMissing = ifelse(is.na(dat$Most_Recent_Max_Bid), 1,0)
		
		### Cum Max Bid
		Check_Condition = dat$Cum_Max_Bid/dat$Most_Recent_List_Price < 0.65
		Check_Condition[is.na(Check_Condition)] = FALSE
		dat$Cum_Max_Bid[Check_Condition] = dat$Most_Recent_List_Price[Check_Condition] * 0.65
			
		Check_Condition = dat$Cum_Max_Bid/dat$Most_Recent_List_Price > 1.22
		Check_Condition[is.na(Check_Condition)] = FALSE
		dat$Cum_Max_Bid[Check_Condition] = dat$Most_Recent_List_Price[Check_Condition] * 1.22
				
		### Most Recent Max Bid
		Check_Condition = dat$Most_Recent_Max_Bid/dat$Most_Recent_List_Price < 0.65
		Check_Condition[is.na(Check_Condition)] = FALSE
		dat$Most_Recent_Max_Bid[Check_Condition] = dat$Most_Recent_List_Price[Check_Condition] * 0.65
		
		Check_Condition = dat$Most_Recent_Max_Bid/dat$Most_Recent_List_Price > 1.22
		Check_Condition[is.na(Check_Condition)] = FALSE
		dat$Most_Recent_Max_Bid[Check_Condition] = dat$Most_Recent_List_Price[Check_Condition] * 1.22
			
		### Difference for Max Cum Bid
		dat$Ind_Numeric_MaxCumBidFirstListPriceDiff = ifelse(is.na(dat$Cum_Max_Bid), 0, dat$Cum_Max_Bid - dat$First_List_Price)
		dat$Ind_Numeric_MaxCumBidMostRecentListPriceDiff = ifelse(is.na(dat$Cum_Max_Bid), 0, dat$Cum_Max_Bid - dat$Most_Recent_List_Price)
			
		### Difference for Max Most Recent Bid	
		dat$Ind_Numeric_MaxMostRecentBidFirstListPriceDiff= ifelse(is.na(dat$Most_Recent_Max_Bid), 0, dat$Most_Recent_Max_Bid - dat$First_List_Price)
		dat$Ind_Numeric_MaxMostRecentBidMostRecentListPriceDiff = ifelse(is.na(dat$Most_Recent_Max_Bid), 0, dat$Most_Recent_Max_Bid - dat$Most_Recent_List_Price)
					
		### Ratio for Max Cum Bid	
		dat$Ind_Numeric_MaxCumBidFirstListPriceRatio = ifelse(is.na(dat$Cum_Max_Bid), 0, dat$Cum_Max_Bid/dat$First_List_Price - 1)
		dat$Ind_Numeric_MaxCumBidMostRecentListPriceRatio= ifelse(is.na(dat$Cum_Max_Bid), 0, dat$Cum_Max_Bid/dat$Most_Recent_List_Price - 1)
			
		### Ratio for Max Most Recent Bid	
		dat$Ind_Numeric_MaxMostRecentBidFirstListPriceRatio = ifelse(is.na(dat$Most_Recent_Max_Bid), 0, dat$Most_Recent_Max_Bid/dat$First_List_Price - 1)
		dat$Ind_Numeric_MaxMostRecentBidMostRecentListPriceRatio = ifelse(is.na(dat$Most_Recent_Max_Bid), 0, dat$Most_Recent_Max_Bid/dat$Most_Recent_List_Price - 1)
		
		### Cum Number of Views
		dat$Total_Cum_Number_Views[is.na(dat$Total_Cum_Number_Views)] = 0
		dat$Most_Recent_Number_Views[is.na(dat$Most_Recent_Number_Views)] = 0

	}
	
	### Group II: Physical property related information
	{
		### Property Size
		dat$Ind_Factor_PropertySize = factor(ifelse(dat$First_List_Price>=600000,"PropertySize6",
											 ifelse(dat$First_List_Price>=300000,"PropertySize5",
											 ifelse(dat$First_List_Price>=200000,"PropertySize4",
											 ifelse(dat$First_List_Price>=100000,"PropertySize3",
											 ifelse(dat$First_List_Price>= 10000,"PropertySize2", 
																				 "PropertySize1"))))),
											levels = c("PropertySize1", "PropertySize2", "PropertySize3", "PropertySize4", "PropertySize5", "PropertySize6"))
		
		### Number of Bed Rooms
		if (sum(is.na(dat$BDRM_CNT_NT))>0) dat$BDRM_CNT_NT[is.na(dat$BDRM_CNT_NT)] = 3
		
		### Number of Bath Rooms
		if (sum(is.na(dat$BTRM_CNT_NM))>0) dat$BTRM_CNT_NM[is.na(dat$BTRM_CNT_NM)] = 2
		
		### Area Sq Feet
		source1 = dat$AREA_SQUR_FEET_NM; source1[source1==0] = NA
		source2 = apply(cbind(dat$LIVINGAREA_FirstList, dat$LIVINGAREA_CurrentList),1, max); source2[source2==0] = NA
		source1[is.na(source1)] = source2[is.na(source1)]
		source1[source1<700 | source1>4000 ] = NA

		### Model for missing Area Sq Feet
		#dat_temp = data.frame(AREA_SQUR_FEET_LOG=log(1+source1),RM_CNT_NT=dat$BDRM_CNT_NT+dat$BTRM_CNT_NM, RM_CNT_NT_SQ=(dat$BDRM_CNT_NT+dat$BTRM_CNT_NM)^2)
		#model_temp = lm(AREA_SQUR_FEET_LOG~RM_CNT_NT + RM_CNT_NT_SQ, data=dat_temp)
		#summary(model_temp)
		#yhat = predict(model_temp, newdata=dat_temp)
		
		AreaSqFeetHat = exp(6.1425 + (dat$BDRM_CNT_NT+dat$BTRM_CNT_NM)*0.2787 - ((dat$BDRM_CNT_NT+dat$BTRM_CNT_NM)^2)*0.00847) - 1
		source1[is.na(source1)] = round(AreaSqFeetHat[is.na(source1)], 0)
		source1[source1<400] = 400
		source1[source1>4000] = 4000
		
		dat$LivingAreaSqFt = source1
		rm(source1); remove(source2); rm(AreaSqFeetHat)
		
		### Lot Size
		dat$LOT_SIZE_VC = as.numeric(as.vector(dat$LOT_SIZE_VC)) 
		dat$LOT_SIZE_VC[is.na(dat$LOT_SIZE_VC)] = 0
		dat$LOT_SIZE_VC[dat$LOT_SIZE_VC<1000] = 1000
		dat$LOT_SIZE_VC[dat$LOT_SIZE_VC>40000] = 40000
		
		### Age of House
		dat$AGE = as.numeric(format(dat$Current_List_Start_Date,"%Y"))-as.numeric(format(dat$BULD_DATE_DT,"%Y"))
		if (sum(is.na(dat$AGE))>0) dat$AGE[is.na(dat$AGE)] = 36
		dat$AGE[dat$AGE<=0] = 1
		dat$AGE[dat$AGE>99] = 99
	
		### House Condition
		if (sum(is.na(dat$CONDITIONCDE_CurrentList))>0) dat$CONDITIONCDE_CurrentList[is.na(dat$CONDITIONCDE_CurrentList)] = "AVERAGE"

	}
	
	### Group III: property value related information
	{
		### Property Valuation
		### lm(dat$ASISMIDMKTVAL_CurrentList~dat$Most_Recent_List_Price)
		if (sum(is.na(dat$ASISMIDMKTVAL_CurrentList))>0) {
			dat$ASISMIDMKTVAL_CurrentList[is.na(dat$ASISMIDMKTVAL_CurrentList)] = 4401 + 0.943*dat$Most_Recent_List_Price[is.na(dat$ASISMIDMKTVAL_CurrentList)]
		}
		
		dat$Ind_Numeric_MostRecentAVFLPRatio = dat$ASISMIDMKTVAL_CurrentList/dat$First_List_Price - 1
		dat$Ind_Numeric_MostRecentAVFLPRatio[dat$Ind_Numeric_MostRecentAVFLPRatio > 0.32] = 0.32
		dat$Ind_Numeric_MostRecentAVFLPRatio[dat$Ind_Numeric_MostRecentAVFLPRatio < -0.20] = -0.20

		dat$Ind_Numeric_MostRecentAVRLPRatio = dat$ASISMIDMKTVAL_CurrentList/dat$Most_Recent_List_Price - 1	
		dat$Ind_Numeric_MostRecentAVRLPRatio[dat$Ind_Numeric_MostRecentAVRLPRatio > 0.32] = 0.32
		dat$Ind_Numeric_MostRecentAVRLPRatio[dat$Ind_Numeric_MostRecentAVRLPRatio < -0.20] = -0.20
		
		dat$Ind_Numeric_MostRecentAVFLPDiff =  dat$ASISMIDMKTVAL_CurrentList - dat$First_List_Price
		dat$Ind_Numeric_MostRecentAVRLPDiff =  dat$ASISMIDMKTVAL_CurrentList - dat$Most_Recent_List_Price
		
		### Repair Value
		dat$TOTREPAIRAMT_CurrentList[is.na(dat$TOTREPAIRAMT_CurrentList)] = 0
		dat$TOTREPAIRAMT_CurrentList[dat$TOTREPAIRAMT_CurrentList<500] = 0
		dat$TOTREPAIRAMT_CurrentList[dat$TOTREPAIRAMT_CurrentList>25000] = 25000
		
		dat$Ind_Numeric_MostRecentTotRepairFLPRatio = -dat$TOTREPAIRAMT_CurrentList/dat$First_List_Price
		dat$Ind_Numeric_MostRecentTotRepairRLPRatio = -dat$TOTREPAIRAMT_CurrentList/dat$Most_Recent_List_Price
	}			
	
	dat$Ind_Dummy_BadCurrentListMonth = ifelse(format(dat$Current_List_Start_Date, "%m") %in% c("8","9","10","11","12"),1,0)
		
	dat$Ind_Dummy_GoodCurrentListMonth = ifelse(format(dat$Current_List_Start_Date, "%m") %in% c("04","05"),1,0)
		
	dat$Ind_Dummy_2013Listing = ifelse(format(dat$Current_List_Start_Date, "%Y") %in% c("2013"),1,0)	
	dat$Ind_Dummy_2014Listing = ifelse(format(dat$Current_List_Start_Date, "%Y") %in% c("2014"),1,0)
	dat$Ind_Dummy_2015Listing = ifelse(format(dat$Current_List_Start_Date, "%Y") %in% c("2015"),1,0)
	dat$Ind_Dummy_2016Listing = ifelse(format(dat$Current_List_Start_Date, "%Y") %in% c("2016"),1,0)
	dat$Ind_Dummy_2017Listing = ifelse(format(dat$Current_List_Start_Date, "%Y") %in% c("2017"),1,0)
	dat$Ind_Dummy_2018Listing = ifelse(format(dat$Current_List_Start_Date, "%Y") %in% c("2018"),1,0)
	dat$Ind_Dummy_2019Listing = ifelse(format(dat$Current_List_Start_Date, "%Y") %in% c("2019"),1,0)

		
	###########################################################################
	#####          				EXPORT OUTPUT	        		  	  	  #####
	###########################################################################
	Outputs = list( Model_Layer_I_Data = dat )
	
	return(Outputs)
	
}
